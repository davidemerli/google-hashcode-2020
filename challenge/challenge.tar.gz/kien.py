Struct = namedtuple('Struct', ['num_books', 'num_libraries', 'days', 'books'])
Book = namedtuple('Book', ['index', 'value'])
Library = namedtuple('Library', ['library_index', 'num_of_books_in_lib', 'days_to_sign', 'books_per_day', 'book_list', 'sorted_book_list'])
